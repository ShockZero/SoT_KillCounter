The Plunderizer v2.0
Sea of Thieves Kill Counter
Created by ShockwaveZ3R0
twitch.tv/shockwavez3r0

For use with Streamlabs UBS.
This application updates text files which can be used by Streamlabs OBS to update kill counters while live streaming.

To target a text file in Streamlabs OBS:
Select the 'Editor' tab
Click the '+' in the 'Scenes' section
Click 'Text (GDI+)' and click 'Add Source'
Enter a name for the text and click 'Add New Source'
Click 'Read from file'
Select a .txt file from the directory this application is located in.

Global Hotkeys:
F1: +1 Kill
F2: +1 Sloop
F3: +1 Brigantine
F4: +1 Galleon
F5: +1 Death
F6: +1 Custom #1
F7: +1 Custom #2
F8: +1 Custom #3